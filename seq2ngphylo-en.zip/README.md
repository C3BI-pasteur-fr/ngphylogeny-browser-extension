# Sequences to NGPhylogeny (Firefox)

A browser extension that detects sequences (nucleotide or protein) on a web page, formats them as FASTA
and pastes them into the **Pasted text** field of the
[One Click](https://ngphylogeny.fr/workflows/oneclick/) page of NGPhylogeny.fr.
**The form is never submitted**: you check it, then start the analysis yourself.

## Installation (temporary, for testing)

1. In Firefox, open `about:debugging#/runtime/this-firefox`
2. Click "Load Temporary Add-on…"
3. Pick `manifest.json` (or the .zip).

The add-on disappears when Firefox restarts. For a permanent install, sign it for free as
"self-distributed" on addons.mozilla.org (`npx web-ext sign`), or use Firefox Developer Edition / ESR
with `xpinstall.signatures.required = false`.

Since Firefox 109, new extensions are not pinned to the toolbar automatically: click the puzzle-piece
icon (Extensions), then the pin next to "Sequences to NGPhylogeny".

## Usage

1. Open a page containing sequences (NCBI, UniProt, an online FASTA file, an article…).
2. Optional: select the text you want. The selection is then offered first;
   a button switches to the whole page.
3. Click the extension icon: the detected sequences are listed (editable name,
   DNA/RNA/protein type, length). Untick anything you don't want.
4. "Send to NGPhylogeny": a new tab opens and the field is filled in
   (the FASTA is also copied to the clipboard as a safety net).

### Recognised formats

FASTA (wrapped or single-line), GenBank (`ORIGIN … //`), EMBL / UniProt flat file (`SQ … //`),
and "bare" sequences (a long line, or blocks of 10 with line numbers).

### Options

- **Short identifiers** (default): `sp|P99999|CYC_HUMAN Cytochrome c` becomes `CYC_HUMAN`.
  Spaces, `:` `,` `(` `)` etc. break the Newick tree format; duplicates get `_2`, `_3`…
- **Remove gaps** (`-`) and the trailing `*`.

Warnings: mixed nucleotides / proteins, fewer than 4 sequences (the page says "more than 3").

## What has been tested, and what has not

- `node test/parser.test.js`: 15 parser tests (formats, false positives on running text, names).
- `test/fill.harness.js` and `test/popup.harness.js` (Playwright / Chromium): pasting into four mock
  forms (visible field, field hidden behind a radio button, field injected late, no field),
  the absence of form submission, and the popup with a mocked `browser` API.
- **Not tested: the real site.** The HTML of ngphylogeny.fr could not be inspected, so the field is
  found heuristically ("Pasted text" label, then attributes, then a lone `<textarea>`).
  If that fails, a banner offers to copy the FASTA. To pin the behaviour down:
  right-click the field > Inspect, then set `CONFIG.textareaSelector`
  at the top of `content/ngphylogeny.js` (e.g. `'#id_xxx'`).

## Known limits

- Only the top frame of the page is analysed (not iframes).
- No extraction on Firefox internal pages, addons.mozilla.org, or in the PDF viewer.
- Sequences rendered as images or on a canvas cannot be read.
- Manifest V2, chosen for Firefox (no host permission to grant). A Chrome port will need MV3
  (`chrome.scripting.executeScript`; no service worker needed here).

## Privacy

Permissions: `activeTab` (reads the page only when you click), `storage` (temporary hand-off of the
FASTA, deleted as soon as it is consumed or after 5 min), `clipboardWrite`, and a content script
limited to `https://ngphylogeny.fr/workflows/oneclick*`. No data is sent anywhere else.
