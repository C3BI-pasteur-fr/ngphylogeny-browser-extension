(() => {
  'use strict';

  const api = globalThis.browser || globalThis.chrome;
  const NG_URL = 'https://ngphylogeny.fr/workflows/oneclick/';
  const MIN_SEQS = 4; // the One Click page says "more than 3 sequences"
  const PREVIEW_MAX = 30000;
  const KEY = 'ngphyloPending';

  const $ = (sel) => document.querySelector(sel);
  const fmt = (n) => n.toLocaleString('en-US');
  const plural = (n, one, many) => (n > 1 ? many : one);

  const TYPE_LABEL = { dna: ['DNA', 'nt'], rna: ['RNA', 'nt'], protein: ['protein', 'aa'] };

  const state = {
    sets: { selection: [], page: [] },
    mode: 'page',
    rows: [], // { header, seq, type, length, checked, name }
  };

  // ---------- list rows ----------

  function loadRows() {
    const short = $('#opt-short').checked;
    state.rows = state.sets[state.mode].map((rec, i) => {
      const base = rec.header || 'seq_' + (i + 1);
      return Object.assign({}, rec, {
        checked: true,
        name: short ? SeqParser.simplifyId(base) : base,
      });
    });
    renderList();
    update();
  }

  function renderList() {
    const list = $('#list');
    list.textContent = '';
    state.rows.forEach((row, i) => {
      const li = document.createElement('li');
      li.className = 'row' + (row.checked ? '' : ' off');

      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = row.checked;
      cb.setAttribute('aria-label', 'Include sequence ' + row.name);
      cb.addEventListener('change', () => {
        row.checked = cb.checked;
        li.classList.toggle('off', !row.checked);
        update();
      });

      const name = document.createElement('input');
      name.type = 'text';
      name.value = row.name;
      name.spellcheck = false;
      name.setAttribute('aria-label', 'Sequence name');
      name.addEventListener('input', () => {
        row.name = name.value;
        update();
      });

      const [label, unit] = TYPE_LABEL[row.type];
      const meta = document.createElement('span');
      meta.className = 'meta';
      meta.textContent = `${label} · ${fmt(row.length)} ${unit}`;

      li.append(cb, name, meta);
      list.appendChild(li);
    });
  }

  // ---------- FASTA generation ----------

  function build() {
    const entries = state.rows
      .filter((r) => r.checked)
      .map((r) => ({ name: r.name, seq: r.seq }));
    const text = SeqParser.buildFasta(entries, { stripGaps: $('#opt-gaps').checked });
    const count = (text.match(/^>/gm) || []).length;
    return { text, count };
  }

  function update() {
    const selected = state.rows.filter((r) => r.checked);
    const total = state.rows.length;
    const { text, count } = build();

    $('#summary-text').textContent =
      `${selected.length} of ${total} ${plural(total, 'sequence', 'sequences')}`;
    const all = $('#select-all');
    all.checked = selected.length === total;
    all.indeterminate = selected.length > 0 && selected.length < total;

    // Warnings
    const warnings = $('#warnings');
    warnings.textContent = '';
    const warn = (msg) => {
      const p = document.createElement('p');
      p.textContent = msg;
      warnings.appendChild(p);
    };
    const kinds = new Set(selected.map((r) => (r.type === 'protein' ? 'prot' : 'nuc')));
    if (kinds.size > 1) {
      warn('Nucleotides and proteins are mixed: a phylogenetic analysis needs a single sequence type.');
    }
    if (selected.length > 0 && selected.length < MIN_SEQS) {
      warn(`The One Click page asks for more than 3 sequences; ${selected.length} selected.`);
    }

    // Preview
    $('#preview').value = text.length > PREVIEW_MAX
      ? text.slice(0, PREVIEW_MAX) + '\n[… preview truncated …]'
      : text;

    $('#send').disabled = count === 0;
    $('#copy').disabled = count === 0;
  }

  // ---------- actions ----------

  function setStatus(msg) { $('#status').textContent = msg; }

  async function copy() {
    const { text, count } = build();
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      setStatus(`FASTA copied (${count} ${plural(count, 'sequence', 'sequences')}).`);
    } catch (e) {
      setStatus('Copy failed: ' + e.message);
    }
  }

  async function send() {
    const { text, count } = build();
    if (!text) return;
    $('#send').disabled = true;
    try {
      await api.storage.local.set({ [KEY]: { fasta: text, count, ts: Date.now() } });
      try { await navigator.clipboard.writeText(text); } catch (_) { /* optional safety net */ }
      await api.tabs.create({ url: NG_URL });
      window.close();
    } catch (e) {
      setStatus('Send failed: ' + e.message);
      $('#send').disabled = false;
    }
  }

  // ---------- startup ----------

  function showEmpty(msg) {
    const p = $('#empty');
    p.textContent = msg;
    p.hidden = false;
    $('#results').hidden = true;
  }

  function setMode(mode) {
    state.mode = mode;
    document.querySelectorAll('#scope button').forEach((b) =>
      b.setAttribute('aria-pressed', String(b.dataset.mode === mode)));
    loadRows();
  }

  async function init() {
    let res;
    try {
      const [tab] = await api.tabs.query({ active: true, currentWindow: true });
      await api.tabs.executeScript(tab.id, { file: '/lib/parser.js' });
      const out = await api.tabs.executeScript(tab.id, { file: '/content/extract.js' });
      res = out && out[0];
    } catch (e) {
      showEmpty('Extraction is not possible on this page (browser-internal page, PDF viewer or restricted site).');
      return;
    }
    if (!res) {
      showEmpty('No response from the page. Reload it and reopen the extension.');
      return;
    }

    state.sets.selection = res.selection || [];
    state.sets.page = res.page || [];
    const nSel = state.sets.selection.length;
    const nPage = state.sets.page.length;

    if (nSel === 0 && nPage === 0) {
      showEmpty('No sequence detected. Select the text of a sequence (FASTA, GenBank, UniProt or raw sequence), then reopen the extension.');
      return;
    }

    $('#results').hidden = false;
    if (nSel > 0) {
      const scope = $('#scope');
      scope.hidden = false;
      scope.querySelector('[data-mode="selection"] .count').textContent = `(${nSel})`;
      scope.querySelector('[data-mode="page"] .count').textContent = `(${nPage})`;
      setMode('selection');
    } else {
      setMode('page');
    }
  }

  // ---------- events ----------

  document.querySelectorAll('#scope button').forEach((b) =>
    b.addEventListener('click', () => setMode(b.dataset.mode)));

  $('#select-all').addEventListener('change', (ev) => {
    state.rows.forEach((r) => { r.checked = ev.target.checked; });
    renderList();
    update();
  });
  $('#opt-short').addEventListener('change', loadRows);
  $('#opt-gaps').addEventListener('change', update);
  $('#copy').addEventListener('click', copy);
  $('#send').addEventListener('click', send);

  init();
})();
